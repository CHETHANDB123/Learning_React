import React from 'react'
import Title from './Hotel_Project/Title/Title'
import Breakfast from './Hotel_Project/Breakfast/Breakfast'
import Dinner from './Hotel_Project/Dinner/Dinner'
import Lunch from './Hotel_Project/Clunch/Lunch'

const App = () => {
  return (
    <div>
      <div className='app-container'></div>
      <Title />
      <Breakfast />
      <Lunch/>
      <Dinner/>
    </div>
  )
}

export default App
