import React from 'react'
import './Dinner.css'
const Dinner = () => {
  return (
    <div>
      <div className="dn-container">
      <div className="heading">
        <h1>Dinner menu</h1>
      </div>
      <div className="cards">
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.y_QNH7EbjsfUZ4dlUYchyQHaEJ?w=258&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.y_QNH7EbjsfUZ4dlUYchyQHaEJ?w=258&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.y_QNH7EbjsfUZ4dlUYchyQHaEJ?w=258&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.y_QNH7EbjsfUZ4dlUYchyQHaEJ?w=258&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.oSWsvvrRoAtconhHmKs0fgHaJ4?w=141&h=188&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.oSWsvvrRoAtconhHmKs0fgHaJ4?w=141&h=188&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.oSWsvvrRoAtconhHmKs0fgHaJ4?w=141&h=188&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Combo Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.oSWsvvrRoAtconhHmKs0fgHaJ4?w=141&h=188&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        </div>
    </div>
    </div>
  )
}

export default Dinner
