import React from 'react'
import "./Breakfast.css";
const Breakfast = () => {
  return (
    <div>
      <div className="bf-container">
      <div className="heading">
        <h1>breakfast menu</h1>
      </div>
      <div className="cards">
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
            </div>
         <div className="card">
            <h1>id.1</h1>
            <h1>iddle vadda</h1>
            <img src="https://th.bing.com/th/id/OIP.kq9TLtN3NGwE5alO1CcBsAHaEC?w=297&h=180&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
     </div>
    </div>
    </div>
  )
}

export default Breakfast
