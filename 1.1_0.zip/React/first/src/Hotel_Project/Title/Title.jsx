import React from 'react'
import './Title.css';
const Title = () => {
  return (
    <div>
      <div className="title-container">
      <h1>welcome to chethan's hotel</h1>
    </div>
    </div>
  )
}

export default Title
