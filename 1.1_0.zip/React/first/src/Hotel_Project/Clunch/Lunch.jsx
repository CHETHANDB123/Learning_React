import React from 'react'
import './Lunch.css'
const Lunch = () => {
  return (
    <div>
      <div className="lu-container">
        <div className="heading">
        <h1>Lunch menu</h1>
      </div>
      <div className="cards">
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
        <div className="card">
            <h1>id.1</h1>
            <h1>Veg Rice</h1>
            <img src="https://th.bing.com/th/id/OIP.dnSCb4Z42B2iqf2JVdliLQAAAA?w=132&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3" alt="" />
            <h3>category</h3>
            <h3>price</h3>
        </div>
      </div>
    </div>
    </div>
  )
}

export default Lunch
