import React from 'react'

const App = () => {

  let me="chethan"

  return (
    <div>
      {/* <div  style={{width:"100%",height:"100%",padding:"20px",display:"flex",justifyContent:"center",alignItems:"center"}} className="container">
        <div style={{width:"150px",display:"flex",flexDirection:"column",height:"400px",alignItems:"center",border:"10px solid black",padding:"10px",borderRadius:"5px"}} className="card">
          <h6 style={{textAlign:"center",fontSize:"20px",fontWeight:"bold"}}>1</h6>
          <h1 style={{textAlign:"center",fontSize:"24px"}}>Title</h1>
          <img style={{width:"100%",height:"100%"}} src="" alt="img loading" />
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto magni iusto officia odit, ullam corrupti cumque facere, impedit voluptates autem nisi necessitatibus laboriosam, ex nesciunt nobis tempore quaerat vel provident.
          </p>
          <button style={{width:"100%",padding:"10px",borderRadius:"5px",padding:"10px 0px" , textTransform:"uppercase"}}>add to cart</button>
          </div>
          </div>     */}
    </div>
  )
}

export default App
